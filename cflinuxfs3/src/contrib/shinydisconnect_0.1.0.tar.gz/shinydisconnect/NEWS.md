# shinydisconnect 0.1.0 (2020-07-14)

Initial CRAN release
