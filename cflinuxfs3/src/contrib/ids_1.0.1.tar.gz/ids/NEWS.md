# ids 1.1.0 (2017-05-22)

* Fix occasionally failing text (removes one animal from the pool)
* New identifier type "proquint"

# ids 1.0.0 (2016-11-03)

* Initial CRAN release
