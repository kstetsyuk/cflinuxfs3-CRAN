Empty folders are removed on upload to ShinyApps.io.

This README ensures this folder is not removed.

Erik.Leppo@tetratech.com
2021-12-22