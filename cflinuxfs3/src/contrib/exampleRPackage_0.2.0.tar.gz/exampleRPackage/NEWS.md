# exampleRPackage 0.2.0

* Changed name from exampleDataPackage to exampleRPackage
* Added a `NEWS.md` file to track changes to the package.



