# User Defined Values

# Time Zone, used in Gage script in dataRetrieval, OlsonNames()
# ContData.env$myTZ <- Sys.timezone() #"America/New_York" (local time zone)
ContData.env$myTZ <- "America/Chicago" # central time zone
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
