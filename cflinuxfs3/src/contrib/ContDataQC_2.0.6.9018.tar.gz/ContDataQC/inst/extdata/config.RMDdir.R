# User Defined Values

# Report Format
ContData.env$myReport.Format <- "docx"  # "html" or "docx" # DOCX requires Pandoc.
ContData.env$myReport.Dir    <- getwd() #file.path(system.file(package="ContDataQC"), "rmd")
