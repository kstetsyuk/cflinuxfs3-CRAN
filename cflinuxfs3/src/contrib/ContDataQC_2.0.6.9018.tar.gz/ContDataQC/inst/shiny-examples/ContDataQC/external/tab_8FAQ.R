# Panel, FAQ

function() {

  tabPanel("8. FAQ"
           , mainPanel(
             includeHTML("www/App_8FAQ.html")

           )## mainPanel ~ END
  ) #tabPanel ~ END
}## FUNCTION ~ END
