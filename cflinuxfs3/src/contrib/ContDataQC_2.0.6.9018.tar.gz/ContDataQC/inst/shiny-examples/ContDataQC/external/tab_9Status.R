# Panel, Status

function() {

  tabPanel("9. Status"
           , mainPanel(
             includeHTML("www/App_9Status.html")

           )## mainPanel ~ END
  )# tabPanel ~ END
}## FUNCTION ~ END
