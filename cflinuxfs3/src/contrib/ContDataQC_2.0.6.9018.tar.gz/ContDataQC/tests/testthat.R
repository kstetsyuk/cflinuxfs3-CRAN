library(testthat)
library(ContDataQC)

test_check("ContDataQC")
