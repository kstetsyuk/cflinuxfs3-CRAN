### R code from vignette source 'dlnmPenalized.Rnw'

###################################################
### code chunk number 1: dlnmPenalized.Rnw:53-55
###################################################
options(continue="  ")
set.seed(13041975)


